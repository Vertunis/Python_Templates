# import MyModule  # Alternative 1

# list1 = [-2, 1, 3]
# list1_max = MyModule.list_max(list1)
# print(list1_max)

# from MyModule import list_max   # Alternative 2

# list1 = [-2, 1, 3]
# list1_max = list_max(list1)
# print(list1_max)

# import MyModule as MM

# list1 = [-2, 1, 3]
# list1_max = MM.list_max(list1)
# print(list1_max)
