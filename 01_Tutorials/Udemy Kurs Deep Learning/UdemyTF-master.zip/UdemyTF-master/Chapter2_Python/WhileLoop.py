start_value = 0
end_value = 10

while start_value < end_value:
    start_value += 2
    print("current value is: ", start_value)
